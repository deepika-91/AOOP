package module1A;
interface Coffee {
    double cost();
    String description();
}