/**
 * 
 */
/**
 * 
 */
module module1A {
	requires junit;
	requires org.junit.jupiter.api;
}